package com.xiaomi.martinrgb.myapplication.Equation;

import android.view.animation.Interpolator;

/**
 * Created by MartinRGB on 2017/7/8.
 */

public class DampingInterpolator implements Interpolator {

    private float amplitude,frictionMultiplier,mass,stiffness,phase;
    private float pulsation,friction;

    public DampingInterpolator(float amplitude, float frictionMultiplier,
                               float mass, float rigidity, float phase) {
        this.amplitude = amplitude;
        this.frictionMultiplier = frictionMultiplier;
        this.mass = mass;
        this.stiffness =rigidity;
        this.phase = phase;

        pulsation = (float) Math.sqrt(stiffness / mass);
        friction = frictionMultiplier * pulsation;


    }

    @Override
    public float getInterpolation(float time){


        return amplitude*(float)Math.exp(-friction * time) *
                (float) Math.cos(pulsation * time + phase);

    }
}
