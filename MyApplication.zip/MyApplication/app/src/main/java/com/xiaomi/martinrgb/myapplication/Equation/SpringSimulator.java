package com.xiaomi.martinrgb.myapplication.Equation;

import android.util.Log;
import android.view.animation.Interpolator;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

/**
 * Created by MartinRGB on 2017/7/8.
 */

public class SpringSimulator implements PropertyChangeListener,Interpolator {
    protected BasicEquation equation;
    protected double time;
    protected int timeScale;


    public SpringSimulator(BasicEquation equation) {
        this.equation = equation;
        this.equation.addPropertyChangeListener(this);
        this.time = 0.0f;
        this.timeScale = 1;
    }

    public void propertyChange(PropertyChangeEvent evt) {
        Log.e("TAG",String.valueOf(time));
    }

    @Override
    public float getInterpolation(float time){
        return (float) equation.compute((double) time);
    }

    public void setTime(double time) {
        this.time = time;
    }

    public double getTime() {
        return this.time;
    }

    public void setTimeScale(int timeScale) {
        this.timeScale = timeScale;
    }

    public int getTimeScale() {
        return this.timeScale;
    }
}
