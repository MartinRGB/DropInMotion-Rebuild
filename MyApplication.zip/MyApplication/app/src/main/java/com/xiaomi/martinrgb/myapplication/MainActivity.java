package com.xiaomi.martinrgb.myapplication;

import android.animation.ObjectAnimator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ImageView;

import com.xiaomi.martinrgb.myapplication.Equation.DampingOscillatorEquation;

public class MainActivity extends AppCompatActivity {

    private ImageView mImageView;
    private boolean mIsClicked =false;
    private DampingOscillatorEquation dampingOscillatorEquation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mImageView = (ImageView) findViewById(R.id.mImageView);

        dampingOscillatorEquation = new DampingOscillatorEquation(1.f,0.f,12.f,0.058f,0.3f);


        mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mIsClicked = !mIsClicked;
                if(mIsClicked){

//                    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(mImageView,"translationY",0f,1000f);
//                    objectAnimator.setInterpolator(new DampingInterpolator(1.f,0.f,12.f,0.058f,0.3f));
//                    objectAnimator.setDuration(1000);
//                    objectAnimator.start();
                    //mImageView.animate().scaleX(1.5f).scaleY(1.5f).setDuration(1000).setInterpolator(new DampingInterpolator(1.f,0.f,12.f,0.058f,0.3f)).start();
                }

                else {
//                    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(mImageView,"translationY",1000f,0f);
//                    objectAnimator.setInterpolator(new DampingInterpolator(1.f,0.f,12.f,0.058f,0.3f));
//                    objectAnimator.setDuration(1000);
//                    objectAnimator.start();
                }

            }
        });





    }
}
