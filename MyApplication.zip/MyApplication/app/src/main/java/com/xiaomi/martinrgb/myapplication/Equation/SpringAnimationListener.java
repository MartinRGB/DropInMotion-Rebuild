package com.xiaomi.martinrgb.myapplication.Equation;

import android.view.animation.Animation;

/**
 * Created by MartinRGB on 2017/7/8.
 */

public class SpringAnimationListener implements Animation.AnimationListener {

    private long start;
    public int timeScale = 1;
    private SpringSimulator springSimulator;
    public SpringAnimationListener(SpringSimulator springSimulator) {
        start = System.currentTimeMillis();
        this.springSimulator = springSimulator;
    }

    @Override
    public void onAnimationStart(Animation animation) {
        long elapsed = System.currentTimeMillis() - start;
        final int DELAY_ANIMATION = 1000;

        if (elapsed > DELAY_ANIMATION * timeScale) {

            springSimulator.setTime(1.0);

        } else {
            double time = (double) elapsed / (double) (DELAY_ANIMATION * timeScale);
            springSimulator.setTime(time);
        }

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }

}
