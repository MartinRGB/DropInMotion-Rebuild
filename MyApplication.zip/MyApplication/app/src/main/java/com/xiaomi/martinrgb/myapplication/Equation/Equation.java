package com.xiaomi.martinrgb.myapplication.Equation;

/**
 * Created by MartinRGB on 2017/7/8.
 */

public interface Equation {
    public double compute(double variable);
}
